{
    "name": "CinnamorollDream",
    "description": "A dreamy pastel RuneLite resource pack inspired by Cinnamoroll and the color blue.",
    "tags": [
      "cinnamoroll",
      "pastel",
      "softcore",
      "sanrio",
      "resource-pack",
      "runelite",
      "custom-ui",
    ]
  }
  