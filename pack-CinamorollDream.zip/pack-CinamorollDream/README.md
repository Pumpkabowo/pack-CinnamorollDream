# CinnamorollDream (by Pumpkabowo)

CinnamorollDream is a cozy, pastel-themed RuneLite resource pack inspired by the adorable Sanrio character, Cinnamoroll. This is my first attempt at creating custom OSRS visuals, blending soft aesthetics with dreamy UI elements to make the gameplay feel extra sweet and comforting, focusing on the color blue! 

As mentioned, this is my first upload of the pack, and it’s just the beginning! I’ll be updating and tweaking things over time as I learn more and continue to refine the theme. Thank you for checking it out and being part of this cozy little project! 💫

Created all elements using Pixilart, Adobe Illistrator, Krita.

Last Updated: 4/04/2025


